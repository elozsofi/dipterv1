from sklearn.metrics import accuracy_score, classification_report
from sklearn.metrics import confusion_matrix


def evaluate_model(y_test, y_pred, model_name="Model"):
    print(f"\n=== {model_name} ===")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("\nClassification report:\n")
    print(classification_report(y_test, y_pred))
    print("\nConfusion matrix:\n")
    print(confusion_matrix(y_test, y_pred))