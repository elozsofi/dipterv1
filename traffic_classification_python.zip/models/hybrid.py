# rule-based + ML

from models.rule_based import classify as rule_classify


class HybridModel:
    def __init__(self, ml_model):
        self.ml_model = ml_model

    def predict(self, X):
        preds = []

        for features in X:
            rule_pred = rule_classify(features)

            if rule_pred != -1:
                return rule_pred
            else:
                preds.append(self.ml_model.predict([features])[0])

        return preds